module.exports = {
  rules: {
    "no-mixed-spaces-and-tabs": 0, // disable rule
  },
};
